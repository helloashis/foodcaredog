@extends('layouts.public-layout')

@section('content')

<div class="site-inner" style="background: url({{ asset('dist/public/images/dog-with-stick.jpg')}}) no-repeat center;">
      <div class="wrap">
        <div class="header">
          <h1 class="entry-title">Food Care Dog Reviews and Ratings</h1>
        </div>
        <div class="content">
          <p>
            Expert opinion. Trusted advice. We help you choose the best food for your dog.
          </p>
          <!--a href="" class="fb-btn">Facebook <span>208k</span></a>
          <a href="" class="fb-btn">Facebook <span>208k</span></a-->
        </div>
      </div>
    </div>

    <div class="container">
      <div class="service-card">
        <div class="row">
          <div class="col-md-6">
            <div class="card">
              <div class="card-body">
                <img src="{{ asset('dist/public/images/Dog-Food.jpg')}}" width="100%" alt="">
              </div>
              <div class="card-footer">
                <h3><a href="{{ route('post-details', 'Best food for french bulldog') }}">Best food for french bulldog</a></h3>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="card">
              <div class="card-body">
                <img src="{{ asset('dist/public/images/Puppy.jpg')}}" width="100%" alt="">
              </div>
              <div class="card-footer">
                <h3><a href="{{ route('post-details', 'Best puppy food for french bulldog') }}">Best puppy food for french bulldog</a></h3>
              </div>
            </div>
          </div>
        </div>
      </div>
      <section class="home-notice">
        <p class="notice-title">Protect Your Dog</p>
        <p class="notice-txt">The Dog Food Advisor offers a FREE Dog Food Recall Alert Service by email.
          <br>
          <a href="https://www.dogfoodadvisor.com/dog-food-recall-alerts/">
            <strong>Click here to sign up now</strong>
          </a>
        </p>
      </section>
    </div>
    
@endsection